
ReadMe file
Created on 8 Feb 2014 by Jeffrey R. Stevens (jeffrey.r.stevens@gmail.com)

**********************************************************
If you use the data, please cite the following:  
Stevens, J.R. (2010). Donor payoffs and other-regarding preferences in cotton-top tamarins (Saguinus oedipus). Animal Cognition, 13, 663-670. doi: 10.1007/s10071-010-0309-x
**********************************************************

Summary: These data were collected from Jun to Sept 2003 as part of a generosity study in cotton-top tamarins at the Cognitive Evolution Lab at Harvard University.

Data file: 

stevens_2010_data.csv
Each row represents a trial for a subject.

actor - subject with the choice to deliver food
recipient - subject who may receive food
cagemate - treatment condition describing whether recipient was actor's cagemate (Y) or an noncagemate of the opposite sex (N)
cond - experimental condition (SB = solo, with barrior, SNB = solo, without barrier, P = paired)
correctside - side (L = left, R = right) that delivers food to available cage in SNB and to recipient in P; blank when no correct pull is possible (e.g., SB condition with trial typs A or B)
rep - replicate number for actor and experimental condition
trial# - trial number within a session
trialtype2 - configuration of food on trays (A = Self and Other, B = Other Only, C = Left Only, D = Right Only)
pull - side of tray pulled (L = left, R = right) or no pull (N)
correct - whether actor pulled left tray for SB trial type C, right tray for SB trial type D, side for self in SNB, or recipient in P (1 = pulled correct, 0 = pulled incorrect, blank = either there is no 'correct' pull [e.g., condition SB trial types C or D] or actor did not pull)
correct.right - whether actor pulled 'correctly' for SNB and P or whether they pulled the right (as opposed to left) tray in SB trial types C and D; gives measure of random pulling/side bias
ppull - whether they pulled either tray, regardless of which they pulled

