
ReadMe file
Created on 8 Feb 2014 by Jeffrey R. Stevens (jeffrey.r.stevens@gmail.com)

**********************************************************
If you use the data, please cite the following:  
Volstorf, J., Rieskamp, J., & Stevens, J.R. (2011). The good, the bad, and the rare: Memory for partners in social interactions. PLoS ONE, 6, e18945. doi: 10.1371/journal.pone.0018945
**********************************************************

Summary: These data were collected in 2010 as part of a cooperative memory study in humans.

Data file: 

volstorf_etal_2011_data.csv
Each row represents the aggregation over participant, session, condition, and partner type

Session - session number
Condition - experimental condition (DefectorsRare = 80% of partners played TFT, EqualProportion = 50% of partners played TFT, CooperatorsRare = 20% of partners played TFT)
Participant - participant number
PartnerType - partner type (defector = All D, cooperator = TFT)
CoopBehavior - percent of trials in which the participant cooperated with that partner
RecognitionHits - percent of memory trials in which the participant correctly recognized a previously seen partner
RecognitionFalseAlarms - percent of memory trials in which the participant claimed to have recognized a partner that they did not actually observe previously
CoopEvaluation - mean ratings of cooperativeness of partners on a scale from 0 (no cooperative actions) to 100 (always cooperative) 
Categorization - mean correct categorization of partners as cooperators or defectors
AccuracyRate -  categorization in conjunction with correct recognition
ChanceLevel - chance level of being accurate given the proportion of partner types in the population

