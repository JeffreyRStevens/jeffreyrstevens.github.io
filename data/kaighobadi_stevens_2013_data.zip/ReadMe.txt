
ReadMe file for data uploaded on Dryad
Created by Jeffrey R. Stevens on 4 Dec 2012 (jeffrey.r.stevens@gmail.com),

************************************************************
If you use these data, please cite the following: 
Kaighobadi, F. & Stevens, J.R. (2013). Does fertility status influence impulsivity and risk taking in human females? Adaptive influences on intertemporal choice and risky decision making. Evolutionary Psychology, 11, 700-717.
************************************************************

Summary: These data were collected from June 2010 to April 2011 as part of an intertemporal choice study in women at Florida Atlantic University.

Data files: 

kaighobadi_stevens_attractiveness.csv--attractiveness ratings
This file includes attractiveness rating data collected for images of males and landscapes.  Each row represents a single trial within a session for a subject. Columns are defined as:
	subject - participant number
	fertility - fertility status (peak or low)
	image - image number
	rating - participant rating of image from 0 (very unattractive) to 9 (very attractive)
	rt - response time--time between exposure to image and rating response (in ms)
	condition - experimental condition (man = male image, L = landscape)

kaighobadi_stevens_choice.csv--intertemporal and risky choice data
This file includes choice data collected during the intertemporal choice and risky choice tasks.  Each row represents a single block of trials within a session for a subject. Columns are defined as:
	subject - participant number
	age - participant age
	condition - experimental condition (experimental [male image] or control [neutral landscape image])
	fertility - fertility status (peak or low)
	date_time - date and time of session in the format YYYY-MM-DDThh:mm:ss (W3C/ISO 8601 date standard)
	session - session number (1 or 2)
	task - order of experimental tasks
	tasktype - experimental task (Discounting [intertemporal choice] or Risk [risky choice])
	block - block number for blocks of questions
	switchpt - indifference point calculated for question
	amount1 - small amount ($)
	time1 - short delay (days) for times or chance out of 10 for probabilities
	amount2 - large amount ($)
	time2 - long delay (days) for times or chance out of 10 for probabilities
	prepost - flag for whether question occurs before or after exposure to images

kaighobadi_stevens_questions.csv--all questions used in experiment
This file includes all question stimuli that were used for the intertemporal choice and risky choice tasks.  Each row represents an individual question. Columns are defined as:
	type - experimental task (Disc [intertemporal choice] or Risk [risky choice])
	block - block number (7 intertemporal choice blocks and 5 risky choice blocks per session)
	amount1 - small amount ($)
	time/prob1 - short delay (days) for times or chance out of 10 for probabilities
	amount2 - large amount ($)
	time/prob2 - long delay (days) for times or chance out of 10 for probabilities

