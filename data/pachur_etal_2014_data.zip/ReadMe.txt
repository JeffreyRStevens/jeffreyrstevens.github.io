
ReadMe file for data uploaded on Dryad
Created by Jeffrey R. Stevens on 30 November 2013 (jeffrey.r.stevens@gmail.com),

**********************************************************
If you use the data, please cite the following: Pachur, T., Schooler, L.J., & Stevens, J.R. (2014). We’ll meet again: Revealing distributional and temporal patterns of social contact. PLoS ONE, 9, e86081. doi: 10.1371/journal.pone.0086081
**********************************************************

Summary: These data were collected as part of a study on social contact patterns in humans.

Data file: 
pachur_etal_data.csv
This file includes contact data collected for 40 participants.  Each row represents a single network member for a participant. Columns are defined as:
	participant - participant number
	age - participant age
	gender - particpant gender
	social_category - relationship to network member (1 = Partner, 2 = Friend, 3 = Flatmate, 4 = Family, 5 = Colleague/study mate, 6 = Acquaintance, 7 = Relative, 8 = Other)
	person - network member number
	1-100 - columns 1-100 represent the days of the study; entries in these cells represent the type of contact with a particular network member on that day (0 = no contact, 1 = participant-initiated face-to-face contact, 2 = participant-initiated email contact, 3 = participant-initiated phone contact, 4 = participant-initiated other contact, 11 = network member-initiated face-to-face contact, 22 = network member-initiated email contact, 33 = network member-initiated phone contact, 44 = network member-initiated other contact). In some cases, participants listed multiple types of contact, and those cases include all listed types of contact (e.g., 144 = both participant-initiated face-to-face contact and network member-initiated other contact).


