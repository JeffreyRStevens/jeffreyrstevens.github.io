README.txt 30 May 2018
Jeffrey R. Stevens (jeffrey.r.stevens@gmail.com)

This file describes how to reproduce the results from the following paper: Stevens, Stevens JR, Woike JK, Schooler LJ, Lindner S, Pachur T. 2018 Social contact patterns can buffer costs of forgetting in the evolution of cooperation. Proceedings of the Royal Society of London: Series B, 20180407. http://dx.doi.org/10.1098/rspb.2018.0407

All materials presented here are released under the Creative Commons Zero license (CC0). You can copy, modify, distribute, and perform the work, even for commercial purposes, all without asking permission.

Unzip stevens_etal_2018_rr.zip into a folder.

To run simulations, unzip stevens_etal_2018_matlab.zip into a folder, ensure that a subfolder named "data" is in the folder with the scripts, and run "stevens_et_al_matlabcode_primary.m" in MATLAB.

To reproduce these analyses, ensure that a subfolder named "figures" is in the folder with all other files.  Next, open stevens_etal_2018_rcode.R and ensure that all packages mentioned at the top of the script are installed.  Once all packages are install, run the script in R using "source("stevens_etal_2018_rcode.R")".  

Once the script runs without errors, you can compile the R Markdown document stevens_etal_2018.Rmd.  Open this file in RStudio and ensure that you have packages 'knitr' and 'rmarkdown' installed.  Once installed, use knitr to compile the document (control-shift-k).  Use the same process to compile stevens_etal_2018_SM.Rmd.

