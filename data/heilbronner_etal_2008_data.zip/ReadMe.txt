
ReadMe file
Created on 8 Feb 2014 by Jeffrey R. Stevens (jeffrey.r.stevens@gmail.com)

**********************************************************
If you use the data, please cite the following:  
Heilbronner, S.R., Rosati, A.G., Stevens, J.R., Hare, B. & Hauser, M.D. (2008). A fruit in the hand or two in the bush? Ecological pressures select for divergent risk preferences in chimpanzees and bonobos. Biology Letters, 4, 246-249. doi: 10.1098/rsbl_2008.0081
**********************************************************

Summary: These data were collected from chimpanzees and bonobos at the Leipzig Zoo.

Data file: 

heilbronner_etal_2008_data.csv
Each row represents a single trial within a session for a subject. Columns are defined as:
  subject - subject name
  species - subject species
  session - session number
  trial_type - trial type (N = number; F = forced; C = choice)
  trial - trial number
  safe_choice - choices for safe option (1 = safe choice, 0 = risky choice)
  side - chosen side

