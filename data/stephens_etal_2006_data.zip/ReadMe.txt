
ReadMe file
Created on 9 Feb 2014 by Jeffrey R. Stevens (jeffrey.r.stevens@gmail.com)

**********************************************************
If you use the data, please cite the following:  
Stephens, D.W., McLinn, C.M., & Stevens, J.R. (2006). Effects of temporal clumping and payoff accumulation on impulsiveness and cooperation. Behavioural Processes, 71, 29-40. doi: 10.1016/j.beproc_2005.09.003
**********************************************************

Summary: These data were collected from Mar 2000 to Apr 2001 from blue jays at University of Minnesota.

Data file: 

stephens_etal_2006_data.csv
 bird - bird id number
 date - data of trial
 stooge_strategy - strategy used by stooge partner (AllD = always defect, TFT = tit-for-tat)
 accumulation - accumulation condition (Accu = accumulated payoffs, No = non-accumulated payoffs)
 trial_number - overall trial number
 coop_choice - choice for cooperation (1) or defection (0)

