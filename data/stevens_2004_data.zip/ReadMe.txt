
ReadMe file
Created on 9 Feb 2014 by Jeffrey R. Stevens (jeffrey.r.stevens@gmail.com)

**********************************************************
If you use the data, please cite the following:  
Stevens, J.R. (2004). The selfish nature of generosity: Harassment and food sharing in primates. Proceedings of the Royal Society of London Series B, 271, 451-456. doi: 10.1098/rspb_2003.2625
**********************************************************

Summary: These data were collected from Jun to Aug 2001 from chimpanzees at Southwest Foundation for Biomedical Research in San Antonio, Texas and from Sep to Nov from squirrel monkeys at Squirrel Monkey Breeding and Research Resource at the University of South Alabama in Mobile, Alabama.

Data file: 

stevens_2004_data.csv
 Date - date of trial
 Species - species of species
 Trial - trial number within session
 Pair - pair number
 Rep - replicate for pair
 Part - partition condition (1 = partition present, 2 = partition absent)
 Mono - monopolizability condition (1 = monopolizable, 2 = not monopolizable)
 Subj - code signifying whether owner assigned subject 1 or 2
 Owner - subject ID for individual given food
 OwnAmt - percent of total food consumed by owner
 BegAmt - percent of total food consumed by beggar
 CollectFar1 - subject 1 collected food far from owner
 CollectFar2 - subject 2 collected food far from owner
 CollectNear1 - subject 1 collected food near owner
 CollectNear2 - subject 2 collected food near owner
 PassSh1 - subject 1 passively shared food
 PassSh2 - subject 2 passively shared food
 ActPsSh1 - subject 1 actively/passively shared food
 ActPsSh2 - subject 2 actively/passively shared food
 ActiveSh1 - subject 1 actively shared food
 ActiveSh2 - subject 2 actively shared food
 Cofeed - cofeeding occurred
 TotSh - total number of sharing events
 TotPASh - total number of passive or active sharing events (passive sharing, active/passive sharing, and active sharing) 
 Steal1 - subject 1 stole food
 Steal2 - subject 2 stole food
 Att1 - subject 1 unsuccessfully attempted to steal food
 Att2 - subject 2 unsuccessfully attempted to steal food
 Beg1 - subject 1 begs for food
 Beg2 - subject 2 begs for food
 ActBeg1 - subject 1 actively begs for food
 ActBeg2 - subject 2 actively begs for food
 Attack1 - subject 1 attacks
 Attack2 - subject 2 attacks
 TotHar - total number of harassment events
 TotActHar - total number of active harassment events (excludes begging)


