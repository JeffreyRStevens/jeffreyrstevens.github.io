
ReadMe file
Created on 9 Feb 2014 by Jeffrey R. Stevens (jeffrey.r.stevens@gmail.com)

**********************************************************
If you use the data, please cite the following:  
Rosati, A.G., Stevens, J.R., and Hauser, M.D. (2006). The effect of handling time on temporal discounting in two New World primates. Animal Behaviour, 71, 1379-1387. doi: 10.1016/j.anbehav_2005.11.012
**********************************************************

Summary: These data were collected from Oct to Dec 2004 from tamarins and marmosets at Harvard's Primate Cognition Laboratory.

Data file: 

rosati_etal_2006_data.csv
 subject - subject name
 species - subject species
 session_type - session type (NORM = normal condition with pellets dispensed at once, INC =  incremental condition with delay between pellets
 long_delay  - long delay to large reward (500 = 5 s, 1000 = 10 s, 1500 = 15 s)
 short_delay - short delay to small reward (50 = 0.5 s)
 trial_type - trial type (0 = forced choice trial, 1 = free choice trial)
 trial_num - trial number
 choice_LL - choice for the LL (1) or the SS (0)
 rt - reaction time between presentation of options and choice
 delay_choice  - delay associated with chosen option (50 = 0.5 s, 500 = 5 s, 1000 = 10 s, 1500 = 15 s)
 handling_time  - handling time period from when food was first available to when the subject placed the last piece in his/her mouth
 amount_choice - reward amount associated with chosen option (2 or 6 food pellets)

