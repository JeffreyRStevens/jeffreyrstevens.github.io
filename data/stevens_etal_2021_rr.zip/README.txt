ReadMe file
Created on 2021-08-27 by Jeffrey R. Stevens (jeffrey.r.stevens@gmail.com)
Finalized on 2021-08-27

**********************************************************
If you use the data, please cite the following:
Stevens, J.R., Goh, F.W., & Cully, T. (2021). Framing attributes in similarity judgments and intertemporal choices.
**********************************************************

Summary: Five data sets were collected. Data set 1 involved 234 undergraduate participants from the University of Nebraska-Lincoln (UNL) Department of Psychology subject pool between Nov 2017 - Mar 2020. Data set 2 involved 259 undergraduate participants from the UNL subject pool between Mar 2020 - Oct 2020. Data set 3 involved 247 undergraduate participants from the UNL subject pool between Feb 2018 - Mar 2020. Data set 4 involved 236 undergraduate participants from the UNL subject pool between Mar 2020 - Apr 2020. Data set 5 involved 229 Amazon Mechanical Turk workers in Feb 2021. In the combined data file, each row represents a single question for a single participant.

License:
All materials presented here are released under the Creative Commons Attribution 4.0 International Public License (CC BY 4.0). You are free to:
    Share — copy and redistribute the material in any medium or format
    Adapt — remix, transform, and build upon the material for any purpose, even commercially.
Under the following terms:
    Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
    No additional restrictions — You may not apply legal terms or technological measures that legally restrict others from doing anything the license permits.

Data files:
stevens_etal_data.csv
 experiment - experiment name and number
 date - date of experimental session
 participant - participant ID
 condition - experimental condition (dollars, cents, days, weeks)
 type - type of trial/question
 smallamount - small amount value
 largeamount - large amount value
 shortdelay - short delay value
 longdelay - long delay value
 response - response to question

R code:
 stevens_etal_2021_rcode.R - code for running computations and generating figures

R Markdown documents:
 stevens_etal_2021.Rmd - R Markdown document with R code embedded for main manuscript
 stevens_etal_2021_SM.Rmd - R Markdown document with R code embedded for supplementary materials

Instructions to reproduce results:
 To reproduce these results, first clone or unzip the Git repository into a folder. Then, ensure that a subfolder named "figures" is in the folder. Next, open stevens_etal_2021_rcode.R and ensure that all packages mentioned at the top of the script are installed.  Once all packages are installed, run the script in R using "source("stevens_etal_2021_rcode.R")".

 Once the script runs without errors, you can compile the R Markdown document stevens_etal_2021.Rmd.  Open this file in RStudio and ensure that you have packages {knitr} and {rmarkdown} installed.  Once installed, use {knitr} to render the document (control-shift-K).  Use the same process to render stevens_etal_2021_SM.Rmd.

