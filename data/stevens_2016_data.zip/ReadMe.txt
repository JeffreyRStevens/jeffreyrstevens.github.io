
ReadMe file
Created on 8 Feb 2015 by Jeffrey R. Stevens (jeffrey.r.stevens@gmail.com)

**********************************************************
If you use the data, please cite the following:  
Stevens, J.R. (2015). Intertemporal similarity: Discounting as a last resort. Journal of Behavioral Decision Making. (manuscript in press). doi:10.1002/bdm.1870
**********************************************************

Summary: These data were collected in three experiments in which participants were asked to make binary intertemporal choices, staircase intertemporal choices, and similarity judgments for reward amounts and time delays.  Experiment 1 used real rewards and delays and was conducted in Berlin, Germany. Experiments 2 and 3 used hypothetical rewards and delays and were conducted in Lincoln, Nebraska.

Data files: 
 stevens_expt[1, 2, or 3]_data--choice data for experiment 1/2/3
Description of the data columns:
  subject - participant number
  question - question number
  type - type of question (binary, staircase, similarity)
  small_amount - small amount for question (in euros)
  large_amount - large amount for question (in euros)
  short_delay - short delay for question (in days)
  long_delay - long delay for question (in days)
  choice - choice for smaller, sooner (1) or larger, later (2)
  rt - decision time from start of trial until choice is made

R code:

jstevens_rcode.R


