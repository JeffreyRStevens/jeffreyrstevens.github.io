
ReadMe file
Created on 1 Apr 2011 by Jeffrey R. Stevens (jeffrey.r.stevens@gmail.com)

**********************************************************
If you use the data, please cite the following:  
Stevens, J.R., Rosati, A.G., Heilbronner, S.R., & Mühlhoff, N. (2011). Waiting for grapes: Expectancy and delayed gratification in bonobos. International Journal of Comparative Psychology, 24, 99-111.
**********************************************************

Summary: These data were collected from Jun to Aug 2007 as part of a delayed gratification study in bonobos at Zoo Berlin.

Data file: 

stevens_etal_2011_IJCP_data.csv
This file includes choice data collected during the delayed gratification task.  Each row represents a single trial within a session for a subject. Columns are defined as:
  subject - name of subject
  date - date of testing
  phase - phase number (1, 2, 3)
  cond - experimenter condition (control, high reliability, low reliability)
  replicate - session number within each phase and condition (phases 1 and 2 have one session each, phase 3 has three sessions)
  exptr_order - code for order of experimenter condition
  session - code for session number
  test_session - code for test session (high or low reliability) number
  trial - trial number
  stop - number of grapes placed before stopping (main dependent variable)
  interrupted - code for interruptions: "no_interruption" if the trial did not have interruptions, otherwise the grape placement number at which the trial was interrupted.

