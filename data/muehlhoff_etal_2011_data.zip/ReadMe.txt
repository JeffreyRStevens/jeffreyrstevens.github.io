
ReadMe file for data uploaded on Dryad
Created by Jeffrey R. Stevens on 26 April 2011 (jeffrey.r.stevens@gmail.com),

*****************************************************
If you use these data, please cite the following: 
Mühlhoff, N., Stevens, J.R., & Reader, S.M. (2011). Spatial discounting of food and social rewards in guppies (Poecilia reticulata). Frontiers in Psychology, 2, 68. doi: 10.3389/fpsyg.2011.00068
*****************************************************

Summary: These data were collected from August 2009 to February 2010 as part of a spatial discounting experiment in guppies (Poecilia reticulata) at Utrecht University.

Data files: 

muehlhoff_disc_data
This file includes choice data collected during the spatial discounting phase of the project.  Each row represents a single trial within a session for a subject. Columns are defined as:
	date.time - date and time of session
	subject - name of subject
	condition - reward type (f=food and s=social)
	smallamt - small reward amount (always 2)
	largeamt - large reward amount (always 6)
	shortdist - distance to small reward (always 20 cm)
	longdist - distance to large reward (in cm)
	forced.free - flag for trial type (either forced or free)
	trial - trial number within a session
	left - reward amount on left side
	right - reward amount on right side
	choice - side of choice
	choice.ll - choice for large reward (0=no and 1=yes)
	initial.main - flag for phase of experiment (i=initial or habituation and m=main experiment)
	both.conditions - flag for whether subject experience both reward type conditions

muehlhoff_eval_data
This file includes data collected during the evaluation phase of the project.  Each row represents a single session for a subject. Columns are defined as:
	subject - name of subject
	amount - number of food items and social partners (either 2 or 6)
	food - number of choices for food
	social - number of choices for social partners

muehlhoff_travel_data
This file includes travel time data collected during the spatial discounting phase of the project.  Each row represents a distance increment for a subject. Columns are defined as:
	subject - name of subject
	condition - reward type (f=food and s=social)
	distance - distance to large reward (in cm)
	traveltime1 - first measurement of travel time for that subject in that condition and distance (in s)
	traveltime2 - second measurement of travel time for that subject in that condition and distance (in s)
	mean_traveltime - mean travel time for that subject in that condition and distance (in s)
	cond_first - flag for whether this condition was experienced first or second (0=second, 1=first)

muehlhoff_visual_data
This file includes data collected during the visual phase of the project.  Each row represents a single session for a subject. Columns are defined as:
	subject - name of subject
	rewardtype - reward type (f=food and s=social)
	smallamt - small reward amount (either 0 or 2)
	largeamt - large reward amount (6)
	shortdist - distance to small reward (either 20 or 120 cm)
	longdist - distance to large reward (120 cm)
	choicess - number of choices for small reward
	choicell - number of choices for large reward


