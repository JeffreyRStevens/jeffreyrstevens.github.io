
ReadMe file
Created on 1 Apr 2011 by Jeffrey R. Stevens (jeffrey.r.stevens@gmail.com)

**********************************************************
If you use these data, please cite the following:  Stevens, J.R., Volstorf, J., Schooler, L.J., & Rieskamp, J. (2011). Forgetting constrains the emergence of cooperative decision strategies. Frontiers in Psychology, 1, 235. doi: 10.3389/fpsyg.2010.00235
**********************************************************

Summary: These data were collected from Mar to Dec 2008 as part of a cooperative memory study in humans.

Data file: 

stevens_etal_2011_FiCS_memory_data.csv
  Subject - name of subject
  Age - age of subject
  correctresponses - total number of correct responses
  numquests - total number of questions received
  SessionDate - date of session
  SessionTime - time of session
  Sex - gender of participant
  TotalPayment - total amount of money received (in euros)
  Trial - the trial number
  CorrectAnswer - the correct key that the participant should press (p = not cooperate and q = cooperate)
  GroupNum - the number for the current group (or replicate)
  GroupSize - the number of partners in the group
  GroupTrials - the trial number within a group
  OldState.ACC - binary value for whether participant was correct on this trial (1 = correct, 0 = incorrect)
  PartnerAction - partner's action chosen in current trial
  PartnerName - name for partner
  ImageFile - name of image file used for partner
  Round - the number for the current round
  RoundTrials - the trial number within a round
  SubjectType - the number representing which of 9 conditions the participant received
  AccumulatedPayment - accumulated amount of money received at that trial
  TotalGroups - total number of groups experienced
  TotalRounds - total number of rounds experienced
  TotalTrials - total number of trials experienced
  TrialsPerGroup - number of trials experienced per group
  InterveningEvents - number of intervening events since last interaction with this partner
stevens_etal_2011_FiCS_simulation_data.csv
  Error - error rate
  gTFT - proportion of simulations won by GTFT strategists
  WSLS - proportion of simulations won by WSLS strategists
  RANDOM - proportion of simulations won by RAND strategists
  GRIM - proportion of simulations won by GRIM strategists
  cTFT - proportion of simulations won by CTFT strategists
  TFT - proportion of simulations won by TFT strategists
  TF2T - proportion of simulations won by TF2T strategists
  AllC - proportion of simulations won by ALLC strategists
  AllD - proportion of simulations won by ALLD strategists
  Coop - proportion of cooperative interactions in final generation

