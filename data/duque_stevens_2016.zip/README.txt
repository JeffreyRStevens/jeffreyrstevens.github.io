ReadMe file
Created on 15 Aug 2016 by Juan F. Duque (jfduque89@gmail.com)

**********************************************************
If you use the data, please cite the following:
Duque, J.F. & Stevens, J.R. (2016). Voluntary food sharing in pinyon jays: the role of dominance and reciprocity. Animal Behavior, 122, 135–144. 
**********************************************************

Summary: These data were extracted from pinyon jay Squad 1 from May 2013 to May 2014 and Squad 2 from May 2014 to September 2014. The duque_stevens_reciprocity_data.csv contains food sharing sessions for every dyad of pinyon jays tested. The duque_stevens_dominance_data.csv contains dominance encounters for every dyad with either a 1 or 0 to show which individual in a dyad obtained food first. 

Data files:
 duque_stevens_reciprocity_data.csv
  squad - squad number
  date - date of session
  daily - designates whether sessions occurred in morning or afternoon if  
   dyads experienced two sessions within a day or single if dyads only experienced  
   one session that day (relevant for reciprocity where successive sessions  
   occurred either the same day or across several days)
  dyad - subject identification numbers for dyad
  session - corresponding session for that dyad of birds; increases by  
   one each time that pair is tested
  donor - the individual bird who could be a potential donor (was given access  
   to food cup during session)
  recipient - the individual bird who could be a potential recipient (was NOT given  
   access to food cup during session)
  shares - number of sharing events (food transfers from donor to recipient)  
   observed for that specific session
  any_shares - scores whether any sharing occurred (0 = no sharing occurred, 1 = 
   sharing occurred)
  direct_recip - scores whether direct reciprocity occurred. NA if donor in current 
   session was also the donor in the previous session with that same partner; 
   if the donor and recipient roles reversed from the previous session to the 
   current one, then: 0 if no sharing occurred in that previous session, 
   1 if sharing occurred in that previous session
  general_recip - scores whether generalized reciprocity occurred. Same as above 
   except for generalized reciprocity partner identity does not matter;  
   therefore the “previous session” is merely the previous session the current 
   donor was tested, regardless of partner. NA if donor in current session was  
   also the donor in its previous session; if the current donor was a recipient
   in its previous session (i.e., reversed roles), then: 0 if no sharing occurred  
   in that previous session, 1 if sharing occurred in that previous session
 duque_stevens_dominance_data.csv
  squad - squad number
   dyad - subject identification numbers for dyad
  dominance - relative dominance score. 0 if first bird from dyad (e.g., bird X 
   from dyad XZ) did NOT get food before the second bird (Z) or 1 if first bird  
   from dyad did get food first (e.g., bird X obtained food prior to bird Z from  
   dyad XZ); NA if no dominance encounter was tested that day

R code:
 duque_stevens_rcode.R-code for running inferential statistics and generating figures

