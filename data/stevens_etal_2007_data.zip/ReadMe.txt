
ReadMe file
Created on 8 Feb 2014 by Jeffrey R. Stevens (jeffrey.r.stevens@gmail.com)

**********************************************************
If you use the data, please cite the following:  
Stevens, J.R., Wood, J.N., & Hauser, M.D. (2007). Quantity trumps number: Discrimination experiments in cotton-top tamarins (Saguinus oedipus) and common marmosets (Callithrix jacchus). Animal Cognition, 10, 429-437. doi: 10.1007/s10071-007-0081-8
**********************************************************

Summary: These data were collected from Jan to Nov 2003 from tamarins and marmosets at Harvard's Primate Cognition Laboratory.

Data file: 

stevens_etal_2007_data1.csv
 subject - subject name
 species - subject species
 session - session number
 trial - trial number
 L - food amount on left side
 R - food amount on right side
 choice - chosen food amount
 side - side chosen
 larger - larger food amount
 smaller - smaller food amount
 ratio - larger amount / smaller amount
 dist - larger amount - smaller amount
 mag - smaller amount
 correct - choice for larger amount (1) or smaller amount (0)

stevens_etal_2007_data2.csv
 subject - subject name
 session - session number
 trial - trial number
 numcond - numerical pair
 sizecorrelation - correlation between number and amount (+ = positive
 sidelarger - side with the larger amount
 density - whether density is the same/symmetric (B) or different/asymmetric (L) between options
 sidechosen - chosen side
 correctchoice - binary description of whether they chose the larger amount (Y = yes, N = no)
 correct - choice for larger amount of pellets (1 = choosing larger, 0 = choosing smaller)

stevens_etal_2007_data3.csv
 subject - name of subject
 session - session number
 trial - trial number
 size - pellet size (= same, + different)
 density - whether density is the same/symmetric (B) or different/asymmetric (L) between options
 cond - condition, combination of size and density (=L same/asymmetric, +L different/asymmetric, +B different/symmetric)
 side - side which has larger amount (R = right, L = left)
 choice - chosen side
 correct - choice for larger amount of pellets (1 = choosing larger, 0 = choosing smaller)

