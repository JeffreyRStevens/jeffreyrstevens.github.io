ReadMe file
Created on 2020-06-01 by Jeffrey R. Stevens (jeffrey.r.stevens@gmail.com)

**********************************************************
If you use the data, please cite the following:
Stevens, J.R., Polzkill Saltzman, A., Rasmussen, T., & Soh, L.-K. (2020). Improving measurements of similarity judgments with machine-learning algorithms.
**********************************************************

Summary: These data were reported in Stevens & Soh (2018). The two data sets were collected from 50 participants from the Adaptive Behavior and Cognition Web Panel at the Max Planck Institute for Human Development in Berlin, Germany in August 2011 and from 73 participants from the University of Nebraska-Lincoln Department of Psychology undergraduate participant pool in December 2014. Each row represents a single question for a single participant.

License:
All materials presented here are released under the Creative Commons Attribution 4.0 International Public License (CC BY 4.0). You are free to:
    Share — copy and redistribute the material in any medium or format
    Adapt — remix, transform, and build upon the material for any purpose, even commercially.
Under the following terms:
    Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
    No additional restrictions — You may not apply legal terms or technological measures that legally restrict others from doing anything the license permits.

Data files:
stevens_etal_data_raw.csv (raw data file from Stevens & Soh (2018))
 dataset - Number for data set (1 or 2)
 subject - Participant ID number with data set as first number
 age - Participant age
 gender - Participant gender
 small - Small value
 large - Large value
 type - Judgment type (Amount = amount judgment; Delay = delay judgment)
 similarity - Similarity judgment (0 = dissimilar; 1 = similar)
 response_time - Response time in seconds from presentation of value pairs to choice
 difference - Numerical difference: L-S
 ratio - Numerical ratio: S/L
 mean_ratio - Mean ratio: S/((S+L)/2)
 log_ratio - Log ratio: log(S/L)
 relative_diff - Relative/proportional difference: (L−S)/L
 disparity - Disparity ratio: (L−S)/((S+L)/2)
 salience - Salience: (L−S)/(S+L)
 discrim - Discriminability: log(L/(L−S))
 logistic - Logistic function: 1/(1+e^(L−S))
stevens_eta_all_data_accuracy.csv (accuracy, precision, and recall data calculated from the analysis)
 data_file - Identifier for data type (Amount or Delay) and set (1 or 2)
 algorithm - Algorithm used
 sample_size - Number of instances used in training set
 train_test - Flag for whether results are for training set or testing set
 subject - Participant ID (includes data set and ID number)
 accuracy - Mean accuracy
 precision - Mean precision
 recall - Mean recall
 order - Order in which training set was drawn (Random or Sequential)
stevens_etal_data_importance.csv (predictor importance data calculated from this analysis)
 data_file - Identifier for data type (Amount or Delay) and set (1 or 2)
 algorithm - Algorithm
 subject - Participant ID (includes data set and ID number)
 predictor - Predictor
 importance - Predictor importance

R code:
 stevens_etal_2020_rcode.R - code for running computations and generating figures

R Markdown documents:
 stevens_etal_2020.Rmd - R Markdown document with R code embedded for main manuscript
 stevens_etal_2020.Rmd - R Markdown document with R code embedded for supplementary materials

Instructions to reproduce results:
 To reproduce these results, first unzip stevens_etal_2020_rr.zip into a folder.  Then, ensure that a subfolder named "figures" is in the folder with all other files.  Next, open stevens_etal_2020_rcode.R and ensure that all packages mentioned at the top of the script are installed.  Once all packages are installed, run the script in R using "source("stevens_etal_2020_rcode.R")".

 Once the script runs without errors, you can compile the R Markdown document stevens_etal_2020.Rmd.  Open this file in RStudio and ensure that you have packages 'knitr' and 'rmarkdown' installed.  Once installed, use knitr to compile the document (control-shift-k).  Use the same process to compile stevens_etal_2020_SM.Rmd.
