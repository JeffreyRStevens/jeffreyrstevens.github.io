
ReadMe file
Created on 8 Jun 2016 by Jeffrey R. Stevens (jeffrey.r.stevens@gmail.com)

**********************************************************
If you use the data, please cite the following:
Stevens, J.R., Marewski, J.N., Schooler, L.J., and Gilby, I.C. (2016). Reflections of the social environment in chimpanzee memory: applying rational analysis beyond humans. Royal Society Open Science.
**********************************************************

Summary: These data were extracted from 19 years of data from the Kanyawara community of chimpanzees in Kibale National Park, Uganda from July 1988 to June 2006. The data rows are dyads of chimpanzees and columns are days. Cell values represent whether the dyad was observed together (1) or not (0) on that day. If neither chimpanzee was observed for more than 70% of the day or if the chimpanzees could not possibly have been in contact (e.g., at least one was not living), the values are blank. 

Data files:
 stevens_data.csv
 	column 1 - ID for chimpanzee #1
 	column 2 - ID for chimpanzee #2
 	column 3 - sex of chimpanzee #1 (1 = male, 2 = female)
 	column 4 - sex of chimpanzee #2 (1 = male, 2 = female)
 	column 5 - flag for whether chimpanzee #1 is mother of chimpanzee #2 (1 = yes, 0 = no)
 	column 6 - flag for whether chimpanzee #2 is mother of chimpanzee #1 (1 = yes, 0 = no)
	columns 7-4701 - cooccurrence matrix for each of 4,695 days of observation (columns) for each dyad (rows) (1 = observed together, 0 = not observed together, blank = missing data)

R code:
 stevens_etal_rcode.R--code for processing data and generating figures

C++ code:
 stevens_etal_frequency.cpp--code for calculating frequency analysis (needed to run R code)
 stevens_etal_recency.cpp--code for calculating recency analysis (needed to run R code)

