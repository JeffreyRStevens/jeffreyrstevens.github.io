README.txt 17 Oct 2017
Jeffrey R. Stevens (jeffrey.r.stevens@gmail.com)

This file describes how to reproduce the results from the following paper: Stevens, J.R. & Soh, L.-K. (2018). Predicting similarity judgments in intertemporal choice with machine learning. Psychonomic Bulletin & Review. 

All materials presented here are released under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International license (CC BY-NC-SA 4.0). You may share and adapt this content with attribution, for non-commercial purposes if you ShareAlike (distribute any contributions under the same license).

To reproduce these results, first unzip stevens_soh_2018_rr.zip into a folder.  Then, ensure that a subfolder named "figures" is in the folder with all other files and a subfolder named "trees" is in the "figures" subfolder.  Next, open stevens_soh_2018_rcode.R and ensure that all packages mentioned at the top of the script are installed.  Once all packages are install, run the script in R using "source("stevens_soh_2018_rcode.R")".  

Once the script runs without errors, you can compile the R Markdown document stevens_soh_2018.Rmd.  Open this file in RStudio and ensure that you have packages 'knitr' and 'rmarkdown' installed.  Once installed, use knitr to compile the document (control-shift-k).  Use the same process to compile stevens_soh_2018_SM.Rmd.
