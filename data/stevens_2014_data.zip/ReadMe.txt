
ReadMe file
Created on 11 Apr 2014 by Jeffrey R. Stevens (jeffrey.r.stevens@gmail.com)

**********************************************************
If you use the data, please cite the following:  
Stevens, J.R. (2014). Evolutionary pressures on primate intertemporal choice. Proceedings of the Royal Society of London, Series B, 281, 20140499. DOI:10.1098/rspb.2014.0499.
**********************************************************

Summary: These data were collected from the primary literature.

Data file: 

stevens_data.csv--intertemporal choice and comparative data
 subject - name of subject if available
 species - species (common name) of subject (e.g., Marmoset)
 type - specific common name of subject (e.g., Common)
 latin_name - Latin name of species
 measure - type of data (indiff = indifference point, bodywt = body weight, ecv = endocranial volume, groupsize = group size, homerange = home range, lifespan = lifespan)
 value - value for specific measure (units: indifference point = seconds, body weight = grams, endocranial volume = cubic centimeters, group size =  individuals, home range = hectares, lifespan = years)
 n - number of samples
 sd - standard deviation of samples
 reference - citation for source of data
 notes - miscellaneous notes on the measure, value, or source

R code:

stevens_rcode.R


