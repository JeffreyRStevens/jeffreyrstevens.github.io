
ReadMe file
Created on 9 Feb 2014 by Jeffrey R. Stevens (jeffrey.r.stevens@gmail.com)

**********************************************************
If you use the data, please cite the following:  
Stephens, D.W., McLinn, C.M., & Stevens, J.R. (2002). Discounting and reciprocity in an Iterated Prisoner's Dilemma. Science, 298, 2216-2218. doi: http://dx.doi.org/10.1126/science.1078498
**********************************************************

Summary: These data were collected from Mar 2000 to Apr 2001 from blue jays at University of Minnesota.

Data file: 

stephens_etal_2002_data.csv
 bird - bird id number
 date - data of trial
 stooge_strategy - strategy used by stooge partner (AllD = always defect, TFT = tit-for-tat)
 accumulation - accumulation condition (Accu = accumulated payoffs, No = non-accumulated payoffs)
 trial_number - overall trial number
 coop_choice - choice for cooperation (1) or defection (0)

