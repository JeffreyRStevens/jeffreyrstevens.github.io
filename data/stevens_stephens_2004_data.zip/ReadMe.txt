
ReadMe file
Created on 9 Feb 2014 by Jeffrey R. Stevens (jeffrey.r.stevens@gmail.com)

**********************************************************
If you use the data, please cite the following:  
Stevens, J.R. and Stephens, D.W. (2004). The economic basis of cooperation: Trade-offs between selfishness and generosity. Behavioral Ecology, 15, 255-261. doi: 10.1093/beheco/arh006
**********************************************************

Summary: These data were collected from blue jays at the University of Minnesota.

Data file: 

stevens_stephens_2004_data.csv
 Pair - pair number
 Trt - payoff matrix (dd = defect only, oc = opponent control, pd = prisoner's dilemma)
 Block - block of 333 trials (1, 2, or 3)
 Trial - trial number
 Bird1_coop - bird 1's choice of cooperation (1) or defection (0)
 Bird2_coop - bird 2's choice of cooperation (1) or defection (0)

