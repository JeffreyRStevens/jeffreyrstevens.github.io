
ReadMe file
Created on 9 Feb 2014 by Jeffrey R. Stevens (jeffrey.r.stevens@gmail.com)

**********************************************************
If you use the data, please cite the following:  
Stevens, J.R., Hallinan, E.V., and Hauser, M.D. (2005). The ecology and evolution of patience in two New World primates. Biology Letters, 1, 223-226. doi: 10.1098/rsbl_2004.0285
********************************************************** 

Summary: These data were collected from Sep 2003 to Apr 2004 from cotton-top tamarins and common marmosets at Harvard University's Cognitive Evolution Lab.

Data file: 

stevens_etal_2005_BiolLett_data.csv
 Month - month of trial
 Day - day of trial
 Time - time of session
 Track - track number for video tape
 Species - species of subject
 Subject - name of subject
 Condition - short delay to small amount
 Trial - trial number within a session
 Choice - chosen amount (2 = two food pellets, 6 = six food pellets)
 Total - total choices of large amount (out of 10) for session

