
ReadMe file for data uploaded on Dryad
Created by Jeffrey R. Stevens on 20 Sept 2011 (jeffrey.r.stevens@gmail.com),

************************************************************
If you use these data, please cite the following: 
Stevens, J.R. & Mühlhoff, N. (2012). Intertemporal choice in lemurs. Behavioural Processes, 89, 121-127. doi: 10.1016/j.beproc_2011.10.002
************************************************************

Summary: These data were collected from Nov 2007 to Jul 2009 as part of an intertemporal choice in lemurs at Tierpark Berlin.

Data files: 

stevens_lemur_data
This file includes choice data collected during the intertemporal choice task.  Each row represents a single trial within a session for a subject. Columns are defined as:
   date_time - date and time of session in the formate YYYYMMDDThhmmss (if the time is missing, we used 01:00)
   subject - name of subject
   species - species of subject
   sex - sex of subject
   main - flag for whether in the main experiment (1) or the training (0)
   lt - delay to large amount (adjusting)
   free - free-choice trial (1) or forced-choice trial (0)
   trial - trial number within a session
   L - amount presented on left side
   R - amount presented on right side
   choice_side - side chosen by subject
   completed - flag representing whether the session was valid (1) or not (0)
   time_available - time at which food became available for subject
   start_eat - time at which subject put first food in mouth
   end_eat - time at which subject put last food in mouth

stevens_comparative_data
This file includes data collected from various other published experiments on species experiencing intertemporal choice tasks.  Each row represents a subject. Columns are defined as:
   subject - name of subject
   species - species of subject
   type - specific description of species
   latin_name - scientific name of species
   exp_cond - experimental condition: 2v6 is two vs. six food items, 1v3 is one vs. three food items, and other is a different adjusting delay scheme
   indiff - mean adjusting delay at indifference for each subject (primary dependent variable for comparative analysis)
   body_wt - body mass of specific individual or mean for species
   indiff_ref - reference for mean adjusting delay at indifference data
   body_wt_ref - reference for body mass data



