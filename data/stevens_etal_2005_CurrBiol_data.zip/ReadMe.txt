
ReadMe file
Created on 9 Feb 2014 by Jeffrey R. Stevens (jeffrey.r.stevens@gmail.com)

**********************************************************
If you use the data, please cite the following:  
Stevens, J.R., Rosati, A.G., Ross, K.R., and Hauser, M.D. (2005). Will travel for food: Spatial discounting and reward magnitude in two New World monkeys. Current Biology, 15, 1855-1860. doi: 10.1016/j.cub_2005.09.016
********************************************************** 

Summary: These data were collected from Sep to Dec 2004 from cotton-top tamarins and common marmosets at Harvard University's Cognitive Evolution Lab.

Data file: 

stevens_etal_2005_CurrBiol_data.csv
 Date - date of session
 Track - track number for video tape
 Subject - subject name
 Species - subject species
 Trial - trial number within session
 LongDistance - distance to large reward
 SmallPellet - smaller amount of food pellets
 LargePellet - larger amount of food pellets (3 or 6)
 LargeSide - side for large amount (1 or 2)
 Choice - choice for large (3 or 6) or small (1 or 2) amount
 TotalLarge - total number of choices for large amount (out of 8) for that session

